/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package challenge5;
import java.util.Scanner;

/**
 *
 * @author nazqu
 */
public class Challenge5 {

    public static String changeXY(String userinput)
    {
        if(userinput.length() == 0)
        {
            return "";
        }
        else if (userinput.charAt(0) == 'x')
        {
            return 'y' + changeXY(userinput.substring(1));
        }
        else
            {
            return userinput.charAt(0) + changeXY(userinput.substring(1));
            } 
    }
    public static void main(String[] args) 
    {
        String userinput;
        Scanner keyboard = new Scanner(System.in);
        //Program start
        System.out.println("Welcome to the x to y converter!");
        System.out.println("Please enter a word to continue.");
        userinput = keyboard.nextLine();
        System.out.println(changeXY(userinput)); // will print the string that the user inputted and call the method to change the x's to y's.
    }
    
}
